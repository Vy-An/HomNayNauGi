import { fetchAPI } from '../../api.js?v=20261014d';

// ============================================================================
// RICH SAMPLE DATASET: 36 Authentic Vietnamese Dishes
// Conforms to Dish Entity: id, name, image, time, cooking_time_minutes, rating, 
// rating_count, likes, is_favorite, category, sub_category, difficulty, 
// description, ingredients, tags, author
// ============================================================================
// Toàn bộ danh sách món ăn được nạp động từ Database Backend
const initialDishes = [];

// Lazy Loading Batch Configuration
const BATCH_SIZE = 12;

const sortOptions = [
    { value: 'newest', icon: 'fa-clock', label: 'Mới nhất' },
    { value: 'popular', icon: 'fa-fire', label: 'Phổ biến nhất' },
    { value: 'likes', icon: 'fa-heart', label: 'Được yêu thích' },
    { value: 'rating', icon: 'fa-star', label: 'Đánh giá cao' },
    { value: 'time_asc', icon: 'fa-hourglass-start', label: 'Thời gian nấu tăng dần' },
    { value: 'time_desc', icon: 'fa-hourglass-end', label: 'Thời gian nấu giảm dần' },
    { value: 'name_asc', icon: 'fa-arrow-down-a-z', label: 'Tên A → Z' }
];

const FoodList = {
    render: async () => {
        return `
        <div class="cozy-kitchen-bg min-h-screen text-text-main font-sans selection:bg-primary/20 selection:text-primary pb-20">
            
            <!-- ======================================================== -->
            <!-- 1. HERO SECTION & LARGE SEARCH BAR                       -->
            <!-- ======================================================== -->
            <section class="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-4">
                <div class="relative bg-gradient-to-r from-[#FFFDF9] via-[#FBF8F1] to-[#F5EBD4]/75 rounded-[28px] p-6 sm:p-8 lg:p-10 border border-beige-border/80 shadow-sm overflow-hidden flex flex-col lg:flex-row items-center justify-between gap-8">
                    
                    <!-- Decorative Ambience Blobs -->
                    <div class="absolute -top-12 -left-12 w-56 h-56 bg-primary/10 rounded-full blur-3xl pointer-events-none"></div>
                    <div class="absolute -bottom-10 right-20 w-60 h-60 bg-accent/15 rounded-full blur-3xl pointer-events-none"></div>

                    <!-- Left: Hero Text, Search Bar & Quick Categories -->
                    <div class="relative z-10 w-full lg:max-w-2xl space-y-4">
                        
                        <!-- Top Badge -->
                        <div class="inline-flex items-center gap-2 bg-primary-subtle border border-primary-light/40 px-3.5 py-1 rounded-full text-xs font-bold text-primary shadow-2xs">
                            <i class="fa-solid fa-kitchen-set text-accent text-xs"></i>
                            <span>Nấu ngon mỗi ngày</span>
                        </div>

                        <!-- Main Heading -->
                        <h1 class="text-2xl sm:text-3xl lg:text-[38px] font-extrabold text-text-main tracking-tight leading-tight">
                            Khám phá <span class="text-primary font-caveat text-3xl sm:text-4xl lg:text-[46px] font-bold inline-block">Từ Điển Ẩm Thực</span>
                        </h1>

                        <!-- Subtitle -->
                        <p class="text-text-muted text-xs sm:text-sm lg:text-base leading-relaxed font-medium">
                            Hàng ngàn công thức món ngon, dễ làm, phù hợp với mọi bữa ăn trong gia đình.
                        </p>

                        <!-- Large Search Bar -->
                        <div class="pt-1">
                            <form id="hero-search-form" class="relative flex items-center w-full bg-white rounded-full border-2 border-[#DFD5BE] focus-within:border-primary focus-within:ring-3 focus-within:ring-primary/15 shadow-sm transition-all duration-200 p-1.5">
                                <span class="pl-3.5 pr-2 text-primary text-base sm:text-lg flex items-center justify-center">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </span>
                                <input 
                                    type="text" 
                                    id="hero-search-input"
                                    placeholder="Tìm kiếm món ăn, nguyên liệu..." 
                                    class="w-full bg-transparent text-xs sm:text-sm font-medium text-text-main placeholder:text-gray-400 focus:outline-none px-2"
                                    aria-label="Tìm kiếm món ăn"
                                />
                                <button 
                                    type="button" 
                                    id="btn-clear-search" 
                                    class="hidden p-1 text-gray-400 hover:text-gray-600 transition-colors mr-1 cursor-pointer"
                                    title="Xóa tìm kiếm"
                                >
                                    <i class="fa-solid fa-circle-xmark text-sm"></i>
                                </button>
                                <button 
                                    type="submit" 
                                    id="btn-hero-search-submit"
                                    class="px-4.5 py-2.5 bg-primary hover:bg-[#1B4633] active:bg-[#143627] text-white font-bold text-xs sm:text-sm rounded-full shadow-md shadow-primary/20 hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer shrink-0"
                                >
                                    <span>Tìm kiếm</span>
                                    <i class="fa-solid fa-arrow-right text-[11px]"></i>
                                </button>
                            </form>
                        </div>

                        <!-- Quick Category Pills -->
                        <div class="pt-1 flex flex-wrap items-center gap-2" id="quick-category-pills">
                            <span class="text-xs font-bold text-text-muted mr-1 hidden sm:inline">Danh mục:</span>
                            <button type="button" class="quick-cat-btn px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-[#E5DEC9] bg-white/80 text-text-muted hover:text-primary hover:bg-primary-subtle shadow-2xs" data-cat="viet">
                                <i class="fa-solid fa-bowl-food text-amber-600 text-xs"></i>
                                <span>Món Việt</span>
                            </button>
                            <button type="button" class="quick-cat-btn px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-[#E5DEC9] bg-white/80 text-text-muted hover:text-primary hover:bg-primary-subtle shadow-2xs" data-cat="nhanh">
                                <i class="fa-solid fa-bolt text-amber-500 text-xs"></i>
                                <span>Món Nhanh</span>
                            </button>
                        </div>

                    </div>

                    <!-- Right: Visual Food Photography Feature Image -->
                    <div class="relative z-10 shrink-0 w-full lg:w-auto flex items-center justify-center">
                        <div class="relative w-64 h-64 sm:w-72 sm:h-72 rounded-[24px] overflow-hidden border-4 border-white shadow-xl group">
                            <img 
                                src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&auto=format&fit=crop&q=80" 
                                alt="Món ăn Việt Nam gia đình" 
                                class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                                loading="lazy"
                            />
                            <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                            
                            <!-- Floating Badge 1 -->
                            <div class="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-full shadow-md text-[11px] font-extrabold text-primary flex items-center gap-1.5">
                                <i class="fa-solid fa-fire text-accent"></i>
                                <span>120+ Công thức</span>
                            </div>

                            <!-- Floating Badge 2 -->
                            <div class="absolute bottom-3 right-3 bg-black/65 backdrop-blur-md px-3 py-1 rounded-full text-white text-[11px] font-bold flex items-center gap-1">
                                <i class="fa-solid fa-star text-yellow-400"></i>
                                <span>4.9 / 5 (3.2k)</span>
                            </div>
                        </div>
                    </div>

                </div>
            </section>


            <!-- ======================================================== -->
            <!-- 2. MAIN CONTENT: 2-COLUMN LAYOUT                         -->
            <!-- LEFT COLUMN: FILTER CARD + RANDOM WIDGET (~320px)        -->
            <!-- RIGHT COLUMN: TOOLBAR + RECIPE GRID + INFINITE SCROLL    -->
            <!-- ======================================================== -->
            <main class="recipe-page-layout max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-4 grid grid-cols-1 lg:grid-cols-[320px_minmax(0,1fr)] gap-6 lg:gap-7 items-start">
                
                <!-- ---------------------------------------------------- -->
                <!-- LEFT COLUMN: LEFT SIDEBAR (STICKY ~320px)            -->
                <!-- ---------------------------------------------------- -->
                <aside class="left-sidebar w-full lg:sticky lg:top-[76px] lg:self-start space-y-3" id="desktop-left-sidebar">
                    
                    <!-- BLOCK 1: BỘ LỌC NHANH (FILTER CARD) -->
                    <section class="filter-card bg-white rounded-[20px] border border-beige-border/80 p-3.5 sm:p-4 shadow-sm space-y-2.5">
                        
                        <!-- Sidebar Header -->
                        <div class="flex items-center justify-between pb-2 border-b border-[#F0EBE0]">
                            <div class="flex items-center gap-1.5">
                                <span class="w-5.5 h-5.5 rounded-lg bg-primary-subtle text-primary flex items-center justify-center text-[10px] font-bold">
                                    <i class="fa-solid fa-sliders"></i>
                                </span>
                                <h2 class="text-xs font-extrabold uppercase tracking-wider text-text-main">
                                    Bộ lọc nhanh
                                </h2>
                            </div>
                            <button type="button" id="btn-reset-filters-sidebar" class="text-[10px] font-bold text-text-muted hover:text-red-500 transition-colors cursor-pointer flex items-center gap-1" title="Đặt lại bộ lọc">
                                <i class="fa-solid fa-rotate-left text-[9px]"></i>
                                <span>Đặt lại</span>
                            </button>
                        </div>

                        <!-- Group 1: LOẠI MÓN -->
                        <div class="space-y-1">
                            <h3 class="text-[10px] font-extrabold uppercase tracking-wider text-text-muted">
                                Loại món
                            </h3>
                            <div class="grid grid-cols-2 gap-1.5" id="filter-category-group">
                                <button type="button" class="btn-filter-cat px-2 py-1.5 rounded-lg text-[11px] font-semibold text-text-muted text-left transition-all border border-gray-100 hover:bg-cream-soft hover:text-primary cursor-pointer flex items-center justify-between" data-cat="Món mặn">
                                    <span class="flex items-center gap-1.5 min-w-0">
                                        <i class="fa-solid fa-drumstick-bite text-amber-600 text-[11px] w-3.5 text-center shrink-0"></i>
                                        <span class="truncate">Món mặn</span>
                                    </span>
                                </button>
                                <button type="button" class="btn-filter-cat px-2 py-1.5 rounded-lg text-[11px] font-semibold text-text-muted text-left transition-all border border-gray-100 hover:bg-cream-soft hover:text-primary cursor-pointer flex items-center justify-between" data-cat="Món canh">
                                    <span class="flex items-center gap-1.5 min-w-0">
                                        <i class="fa-solid fa-bowl-food text-emerald-600 text-[11px] w-3.5 text-center shrink-0"></i>
                                        <span class="truncate">Món canh</span>
                                    </span>
                                </button>
                                <button type="button" class="btn-filter-cat px-2 py-1.5 rounded-lg text-[11px] font-semibold text-text-muted text-left transition-all border border-gray-100 hover:bg-cream-soft hover:text-primary cursor-pointer flex items-center justify-between" data-cat="Món kho">
                                    <span class="flex items-center gap-1.5 min-w-0">
                                        <i class="fa-solid fa-fire-burner text-amber-700 text-[11px] w-3.5 text-center shrink-0"></i>
                                        <span class="truncate">Món kho</span>
                                    </span>
                                </button>
                                <button type="button" class="btn-filter-cat px-2 py-1.5 rounded-lg text-[11px] font-semibold text-text-muted text-left transition-all border border-gray-100 hover:bg-cream-soft hover:text-primary cursor-pointer flex items-center justify-between" data-cat="Món xào">
                                    <span class="flex items-center gap-1.5 min-w-0">
                                        <i class="fa-solid fa-fire-flame-curved text-orange-500 text-[11px] w-3.5 text-center shrink-0"></i>
                                        <span class="truncate">Món xào</span>
                                    </span>
                                </button>
                                <button type="button" class="btn-filter-cat px-2 py-1.5 rounded-lg text-[11px] font-semibold text-text-muted text-left transition-all border border-gray-100 hover:bg-cream-soft hover:text-primary cursor-pointer flex items-center justify-between" data-cat="Món chiên">
                                    <span class="flex items-center gap-1.5 min-w-0">
                                        <i class="fa-solid fa-bacon text-yellow-600 text-[11px] w-3.5 text-center shrink-0"></i>
                                        <span class="truncate">Món chiên</span>
                                    </span>
                                </button>
                                <button type="button" class="btn-filter-cat px-2 py-1.5 rounded-lg text-[11px] font-semibold text-text-muted text-left transition-all border border-gray-100 hover:bg-cream-soft hover:text-primary cursor-pointer flex items-center justify-between" data-cat="Món rau">
                                    <span class="flex items-center gap-1.5 min-w-0">
                                        <i class="fa-solid fa-leaf text-green-600 text-[11px] w-3.5 text-center shrink-0"></i>
                                        <span class="truncate">Món rau</span>
                                    </span>
                                </button>
                                <button type="button" class="btn-filter-cat px-2 py-1.5 rounded-lg text-[11px] font-semibold text-text-muted text-left transition-all border border-gray-100 hover:bg-cream-soft hover:text-primary cursor-pointer flex items-center justify-between" data-cat="Món luộc">
                                    <span class="flex items-center gap-1.5 min-w-0">
                                        <i class="fa-solid fa-droplet text-blue-500 text-[11px] w-3.5 text-center shrink-0"></i>
                                        <span class="truncate">Món luộc</span>
                                    </span>
                                </button>
                            </div>
                        </div>

                        <!-- Group 2: THỜI GIAN NẤU -->
                        <div class="space-y-1 pt-1.5 border-t border-[#F0EBE0]">
                            <h3 class="text-[10px] font-extrabold uppercase tracking-wider text-text-muted">
                                Thời gian nấu
                            </h3>
                            <div class="space-y-0.5" id="filter-time-group">
                                <label class="flex items-center gap-1.5 px-1.5 py-0.5 rounded-md hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="radio" name="cook_time" value="all" checked class="accent-primary w-3 h-3">
                                    <i class="fa-solid fa-clock-rotate-left text-primary text-[10px] w-3.5 text-center"></i>
                                    <span>Tất cả thời gian</span>
                                </label>
                                <label class="flex items-center gap-1.5 px-1.5 py-0.5 rounded-md hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="radio" name="cook_time" value="under_15" class="accent-primary w-3 h-3">
                                    <i class="fa-solid fa-bolt text-amber-500 text-[10px] w-3.5 text-center"></i>
                                    <span>Dưới 15 phút</span>
                                </label>
                                <label class="flex items-center gap-1.5 px-1.5 py-0.5 rounded-md hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="radio" name="cook_time" value="15_to_30" class="accent-primary w-3 h-3">
                                    <i class="fa-regular fa-clock text-blue-500 text-[10px] w-3.5 text-center"></i>
                                    <span>15 – 30 phút</span>
                                </label>
                                <label class="flex items-center gap-1.5 px-1.5 py-0.5 rounded-md hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="radio" name="cook_time" value="above_30" class="accent-primary w-3 h-3">
                                    <i class="fa-solid fa-hourglass-half text-emerald-600 text-[10px] w-3.5 text-center"></i>
                                    <span>Trên 30 phút</span>
                                </label>
                            </div>
                        </div>

                        <!-- Group 3: NGUYÊN LIỆU CHÍNH -->
                        <div class="space-y-1 pt-1.5 border-t border-[#F0EBE0]">
                            <h3 class="text-[10px] font-extrabold uppercase tracking-wider text-text-muted">
                                Nguyên liệu chính
                            </h3>
                            <div class="grid grid-cols-2 gap-x-2 gap-y-1" id="filter-ingredients-group">
                                <label class="flex items-center gap-1.5 px-1.5 py-1 rounded-lg hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="checkbox" value="Thịt heo" class="ingredient-checkbox accent-primary w-3.5 h-3.5 rounded">
                                    <i class="fa-solid fa-bacon text-rose-500 text-[11px] w-3.5 text-center shrink-0"></i>
                                    <span>Thịt heo</span>
                                </label>
                                <label class="flex items-center gap-1.5 px-1.5 py-1 rounded-lg hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="checkbox" value="Thịt gà" class="ingredient-checkbox accent-primary w-3.5 h-3.5 rounded">
                                    <i class="fa-solid fa-drumstick-bite text-amber-600 text-[11px] w-3.5 text-center shrink-0"></i>
                                    <span>Thịt gà</span>
                                </label>
                                <label class="flex items-center gap-1.5 px-1.5 py-1 rounded-lg hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="checkbox" value="Hải sản" class="ingredient-checkbox accent-primary w-3.5 h-3.5 rounded">
                                    <i class="fa-solid fa-fish text-sky-500 text-[11px] w-3.5 text-center shrink-0"></i>
                                    <span>Hải sản</span>
                                </label>
                                <label class="flex items-center gap-1.5 px-1.5 py-1 rounded-lg hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="checkbox" value="Rau củ" class="ingredient-checkbox accent-primary w-3.5 h-3.5 rounded">
                                    <i class="fa-solid fa-carrot text-orange-500 text-[11px] w-3.5 text-center shrink-0"></i>
                                    <span>Rau củ</span>
                                </label>
                                <label class="flex items-center gap-1.5 px-1.5 py-1 rounded-lg hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="checkbox" value="Trứng" class="ingredient-checkbox accent-primary w-3.5 h-3.5 rounded">
                                    <i class="fa-solid fa-egg text-amber-500 text-[11px] w-3.5 text-center shrink-0"></i>
                                    <span>Trứng</span>
                                </label>
                                <label class="flex items-center gap-1.5 px-1.5 py-1 rounded-lg hover:bg-cream-soft transition-colors cursor-pointer text-[11px] font-medium text-text-main">
                                    <input type="checkbox" value="Đậu hũ" class="ingredient-checkbox accent-primary w-3.5 h-3.5 rounded">
                                    <i class="fa-solid fa-cube text-amber-400 text-[11px] w-3.5 text-center shrink-0"></i>
                                    <span>Đậu hũ</span>
                                </label>
                            </div>
                        </div>

                        <!-- Filter Reset Action Button -->
                        <div class="pt-2 border-t border-[#F0EBE0]">
                            <button 
                                type="button" 
                                id="btn-reset-all-filters"
                                class="w-full py-1.5 text-text-muted hover:text-red-600 hover:bg-red-50 border border-gray-100 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                                <i class="fa-solid fa-rotate-left text-[11px]"></i>
                                <span>Đặt lại bộ lọc</span>
                            </button>
                        </div>

                    </section>

                    <!-- BLOCK 2: ✨ RANDOM WIDGET (LUÔN TỒN TẠI DƯỚI BỘ LỌC) -->
                    <section class="random-widget bg-gradient-to-br from-[#1F5B43] via-[#1B4633] to-[#123C28] text-white rounded-[20px] p-3.5 sm:p-4 shadow-sm relative overflow-hidden group">
                        <div class="absolute top-0 right-0 translate-x-3 -translate-y-3 w-16 h-16 bg-accent/20 rounded-full blur-xl pointer-events-none"></div>
                        <div class="relative z-10 space-y-1.5">
                            <div class="inline-flex items-center gap-1 bg-white/15 px-2 py-0.5 rounded-full text-[9px] font-bold text-accent-light">
                                <i class="fa-solid fa-wand-magic-sparkles text-[9px]"></i>
                                <span>Chưa biết ăn gì?</span>
                            </div>
                            <h3 class="text-xs sm:text-sm font-extrabold leading-tight">
                                Random món ngay hôm nay
                            </h3>
                            <p class="text-white/80 text-[11px] font-normal leading-snug">
                                Chọn nhanh thực đơn ngon miệng trong 3 giây.
                            </p>
                            <div class="pt-1">
                                <a 
                                    href="#/" 
                                    class="inline-flex items-center gap-1.5 bg-[#E9A33A] hover:bg-[#D89229] active:bg-[#C78118] text-white font-bold text-[11px] px-3.5 py-1.5 rounded-full shadow-xs hover:scale-[1.02] transition-all cursor-pointer"
                                >
                                    <i class="fa-solid fa-dice text-xs"></i>
                                    <span>Random ngay</span>
                                    <i class="fa-solid fa-arrow-right text-[9px]"></i>
                                </a>
                            </div>
                        </div>
                    </section>

                </aside>


                <!-- ---------------------------------------------------- -->
                <!-- RIGHT COLUMN: RECIPE CONTENT (TOOLBAR + GRID)        -->
                <!-- ---------------------------------------------------- -->
                <section class="recipe-content min-w-0 flex-1 space-y-5" id="recipe-list-section">
                    
                    <!-- Mobile Filter Toggle Bar -->
                    <div class="lg:hidden flex items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-beige-border shadow-2xs">
                        <button 
                            type="button" 
                            id="btn-open-mobile-filter" 
                            class="inline-flex items-center gap-2 bg-primary text-white text-xs font-bold px-4 py-2 rounded-xl shadow-sm cursor-pointer"
                        >
                            <i class="fa-solid fa-sliders"></i>
                            <span>Bộ lọc nhanh</span>
                            <span id="mobile-filter-badge" class="bg-accent text-white w-4 h-4 rounded-full text-[10px] flex items-center justify-center ml-0.5">0</span>
                        </button>
                        <span id="mobile-result-count" class="text-xs font-bold text-text-muted">Đang tải...</span>
                    </div>

                    <!-- RECIPE TOOLBAR: Count + Sort Dropdown + View Toggle -->
                    <div class="recipe-toolbar bg-white rounded-[20px] border border-beige-border/80 p-3 sm:p-4 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3.5">
                        
                        <!-- Left: Dish Count Badge & Active Filters Info -->
                        <div class="flex items-center gap-2.5 w-full sm:w-auto justify-between sm:justify-start">
                            <div class="flex items-center gap-2">
                                <span class="w-7 h-7 rounded-xl bg-primary-subtle text-primary flex items-center justify-center text-xs font-bold">
                                    <i class="fa-solid fa-bowl-food"></i>
                                </span>
                                <span id="recipe-total-count" class="font-extrabold text-sm text-text-main">
                                    Đang tải món ăn...
                                </span>
                            </div>
                            <span id="active-filter-indicator" class="hidden text-[11px] font-semibold text-accent bg-accent/10 border border-accent/20 px-2 py-0.5 rounded-full">
                                Đang lọc
                            </span>
                        </div>

                        <!-- Right: Sort Dropdown & View Mode Switcher -->
                        <div class="flex items-center gap-2.5 w-full sm:w-auto justify-end">
                            
                            <!-- Sort Dropdown -->
                            <div class="relative flex-1 sm:flex-initial" id="sort-dropdown-wrapper">
                                <button 
                                    type="button" 
                                    id="btn-sort-toggle" 
                                    class="w-full sm:w-auto inline-flex items-center justify-between gap-2 px-3 py-2 bg-[#FCFAF6] hover:bg-white border border-[#DFD5BE] rounded-xl text-xs font-bold text-text-main shadow-2xs transition-all cursor-pointer"
                                    aria-haspopup="listbox"
                                    aria-expanded="false"
                                >
                                    <span class="flex items-center gap-1.5">
                                        <i class="fa-solid fa-arrow-down-wide-short text-primary text-[11px]"></i>
                                        <span class="text-text-muted font-normal">Sắp xếp:</span>
                                        <span id="current-sort-label">Mới nhất</span>
                                    </span>
                                    <i class="fa-solid fa-chevron-down text-[10px] text-gray-400"></i>
                                </button>

                                <!-- Dropdown Menu List -->
                                <div id="sort-dropdown-menu" class="hidden absolute top-full right-0 mt-1.5 w-52 bg-white rounded-2xl shadow-xl border border-beige-border p-1.5 z-40">
                                    ${sortOptions.map(opt => `
                                        <button 
                                            type="button" 
                                            class="btn-sort-option w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-text-main hover:bg-primary-subtle hover:text-primary transition-colors flex items-center gap-2 cursor-pointer"
                                            data-sort="${opt.value}"
                                            data-label="${opt.label}"
                                        >
                                            <i class="fa-solid ${opt.icon} text-[11px] text-primary w-4"></i>
                                            <span>${opt.label}</span>
                                        </button>
                                    `).join('')}
                                </div>
                            </div>

                            <!-- View Mode Switcher (Grid / List) -->
                            <div class="inline-flex items-center bg-[#FCFAF6] border border-[#DFD5BE] p-0.5 rounded-xl shadow-2xs">
                                <button 
                                    type="button" 
                                    id="btn-view-grid" 
                                    class="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold bg-primary text-white shadow-2xs transition-all cursor-pointer"
                                    title="Chế độ Lưới (Grid View)"
                                >
                                    <i class="fa-solid fa-grip"></i>
                                </button>
                                <button 
                                    type="button" 
                                    id="btn-view-list" 
                                    class="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-text-muted hover:text-primary transition-all cursor-pointer"
                                    title="Chế độ Danh sách (List View)"
                                >
                                    <i class="fa-solid fa-list"></i>
                                </button>
                            </div>

                        </div>

                    </div>

                    <!-- RECIPE GRID: Strictly 3 cards/row on desktop -->
                    <div id="recipe-grid" class="recipe-grid grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                        <!-- Only recipe cards are appended here -->
                    </div>

                    <!-- LOADING SENTINEL: Detected by IntersectionObserver -->
                    <div id="loading-sentinel" class="w-full py-2"></div>

                    <!-- LOADING STATE / SHIMMER SKELETON / END BADGE -->
                    <div id="loading-state" class="py-4 flex flex-col items-center justify-center w-full">
                        <!-- Shimmer skeletons or end of feed badge -->
                    </div>

                </section>

            </main>


            <!-- ======================================================== -->
            <!-- 3. MOBILE FILTER SLIDE-OVER MODAL                        -->
            <!-- ======================================================== -->
            <div id="mobile-filter-modal" class="fixed inset-0 z-50 hidden">
                <div id="mobile-filter-backdrop" class="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"></div>
                <div class="fixed inset-y-0 right-0 max-w-full flex">
                    <div class="w-screen max-w-sm bg-white p-5 shadow-2xl overflow-y-auto flex flex-col justify-between">
                        <div class="space-y-5">
                            <div class="flex items-center justify-between pb-3 border-b border-gray-100">
                                <h3 class="text-sm font-extrabold uppercase tracking-wider text-text-main flex items-center gap-2">
                                    <i class="fa-solid fa-sliders text-primary"></i>
                                    <span>Bộ lọc tìm kiếm</span>
                                </h3>
                                <button type="button" id="btn-close-mobile-filter" class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 hover:text-black">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                            <p class="text-xs text-text-muted">Chọn các tiêu chí để lọc món ăn nhanh chóng.</p>
                        </div>
                        <div class="pt-4 border-t border-gray-100 space-y-2">
                            <button type="button" id="btn-mobile-apply" class="w-full py-3 bg-primary text-white font-bold text-sm rounded-xl shadow-md cursor-pointer">
                                Xem kết quả
                            </button>
                            <button type="button" id="btn-mobile-reset" class="w-full py-2 bg-gray-100 text-text-muted font-bold text-xs rounded-xl cursor-pointer">
                                Đặt lại tất cả
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- FLOATING TOAST CONTAINER -->
            <div id="foodlist-toast-container" class="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none"></div>

        </div>
        `;
    },

    afterRender: async (params) => {
        // ====================================================================
        // STATE MANAGEMENT (Frontend only)
        // ====================================================================
        let masterDishes = [...initialDishes];
        let currentFilteredDishes = [...masterDishes];
        let currentIndex = 0;
        let isLoading = false;
        let hasMore = true;
        let viewMode = 'grid';
        let currentSort = 'newest';
        let currentSelectedCategories = [];
        let currentQuickCategory = '';
        let currentCookTime = 'all';
        let currentSelectedIngredients = [];
        let currentSearchQuery = '';
        let infiniteScrollObserver = null;
        let searchDebounceTimer = null;
        let latestRequestId = 0;

        // Load API Data gracefully if backend is available
        try {
            const apiRes = await fetchAPI('/foods');
            if (apiRes && apiRes.success && Array.isArray(apiRes.data) && apiRes.data.length > 0) {
                masterDishes = apiRes.data.map(item => ({
                    id: item.id || item.id_food || item.id_monan,
                    name: item.name || item.ten_mon || 'Món ngon',
                    image: item.image || item.hinh_anh || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700',
                    time: item.time || (item.thoi_gian ? `${item.thoi_gian} phút` : '25 phút'),
                    cooking_time_minutes: parseInt(item.cooking_time_minutes || item.thoi_gian || 25, 10),
                    rating: item.rating || 4.8,
                    rating_count: item.rating_count || '1.5k',
                    likes: typeof item.likes !== 'undefined' ? item.likes : 0,
                    is_favorite: Boolean(item.is_favorite ?? item.isFavorite),
                    category: item.category || item.loai_mon || 'Món mặn',
                    category_slug: item.category_slug || '',
                    sub_category: item.sub_category || 'viet',
                    difficulty: item.difficulty || 'Dễ làm',
                    description: item.description || item.mo_ta || 'Món ăn thơm ngon đậm đà cho bữa cơm gia đình.',
                    ingredients: item.ingredients || ['Rau củ', 'Gia vị'],
                    tags: item.tags || ['Món ngon', 'Món Việt'],
                    author: item.author || { name: 'Bếp Nhà', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100' }
                }));
                currentFilteredDishes = [...masterDishes];
            }
            window.masterDishes = masterDishes;
        } catch (e) {
            console.log('Using rich static dataset for FoodList:', e);
            window.masterDishes = masterDishes;
        }

        // DOM Elements
        const heroSearchForm = document.getElementById('hero-search-form');
        const heroSearchInput = document.getElementById('hero-search-input');
        const btnClearSearch = document.getElementById('btn-clear-search');
        const recipeGrid = document.getElementById('recipe-grid');
        const loadingSentinel = document.getElementById('loading-sentinel');
        const loadingState = document.getElementById('loading-state');
        const recipeTotalCountEl = document.getElementById('recipe-total-count');
        const mobileResultCountEl = document.getElementById('mobile-result-count');
        const activeFilterIndicator = document.getElementById('active-filter-indicator');
        const btnViewGrid = document.getElementById('btn-view-grid');
        const btnViewList = document.getElementById('btn-view-list');
        const btnSortToggle = document.getElementById('btn-sort-toggle');
        const sortDropdownMenu = document.getElementById('sort-dropdown-menu');
        const currentSortLabel = document.getElementById('current-sort-label');
        const btnResetAllFilters = document.getElementById('btn-reset-all-filters');
        const btnResetFiltersSidebar = document.getElementById('btn-reset-filters-sidebar');
        
        // Mobile Modal Elements
        const btnOpenMobileFilter = document.getElementById('btn-open-mobile-filter');
        const btnCloseMobileFilter = document.getElementById('btn-close-mobile-filter');
        const mobileFilterModal = document.getElementById('mobile-filter-modal');
        const mobileFilterBackdrop = document.getElementById('mobile-filter-backdrop');
        const btnMobileApply = document.getElementById('btn-mobile-apply');
        const btnMobileReset = document.getElementById('btn-mobile-reset');
        const mobileFilterBadge = document.getElementById('mobile-filter-badge');

        // Toast Notification Helper
        const showToast = (message, type = 'success') => {
            const container = document.getElementById('foodlist-toast-container');
            if (!container) return;

            const toast = document.createElement('div');
            toast.className = `pointer-events-auto transform translate-y-2 opacity-0 transition-all duration-300 flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-xl border text-xs sm:text-sm font-bold ${
                type === 'success' 
                    ? 'bg-primary text-white border-primary-light/40 shadow-primary/20' 
                    : type === 'info'
                    ? 'bg-[#26382F] text-white border-beige-border shadow-black/10'
                    : 'bg-red-600 text-white border-red-500 shadow-red-600/20'
            }`;

            const icon = type === 'success' 
                ? '<i class="fa-solid fa-circle-check text-accent-light text-base"></i>' 
                : type === 'info'
                ? '<i class="fa-solid fa-circle-info text-accent text-base"></i>'
                : '<i class="fa-solid fa-circle-exclamation text-yellow-300 text-base"></i>';

            toast.innerHTML = `${icon}<span>${message}</span>`;
            container.appendChild(toast);

            requestAnimationFrame(() => {
                toast.classList.remove('translate-y-2', 'opacity-0');
                toast.classList.add('translate-y-0', 'opacity-100');
            });

            setTimeout(() => {
                toast.classList.remove('translate-y-0', 'opacity-100');
                toast.classList.add('translate-y-2', 'opacity-0');
                setTimeout(() => toast.remove(), 300);
            }, 2500);
        };

        // ====================================================================
        // CREATE RECIPE CARD ELEMENT
        // ====================================================================
        const createRecipeCardElement = (dish) => {
            const isFav = !!dish.is_favorite || (typeof window !== 'undefined' && window.isDishFavorite && window.isDishFavorite(dish.id));
            const link = `#/mon-an/${dish.id}`;
            const article = document.createElement('article');

            if (viewMode === 'list') {
                article.className = "bg-white rounded-[20px] border border-beige-border/80 p-3.5 sm:p-4.5 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col sm:flex-row gap-4 group col-span-full cursor-pointer";
                article.id = `dish-card-${dish.id}`;
                article.setAttribute('data-dish-id', dish.id);
                article.setAttribute('data-link', link);
                article.innerHTML = `
                    <div class="relative w-full sm:w-56 aspect-[16/10] sm:aspect-square rounded-2xl overflow-hidden bg-cream-soft shrink-0">
                        <img 
                            src="${dish.image}" 
                            alt="${dish.name}" 
                            class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                            loading="lazy" 
                            decoding="async"
                            onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500'"
                        />
                        <div class="absolute bottom-2.5 left-2.5 bg-black/60 backdrop-blur-md text-white px-2.5 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 shadow-sm">
                            <i class="fa-regular fa-clock text-accent-light text-[10px]"></i>
                            <span>${dish.time}</span>
                        </div>
                        <button 
                            type="button" 
                            class="btn-favorite-dish absolute top-2.5 right-2.5 w-8 h-8 rounded-full ${isFav ? 'bg-rose-500 text-white' : 'bg-white/90 text-gray-500 hover:text-rose-500'} backdrop-blur-sm flex items-center justify-center shadow-sm hover:scale-110 transition-all cursor-pointer z-10" 
                            data-id="${dish.id}" 
                            aria-label="Thêm vào yêu thích"
                        >
                            <i class="${isFav ? 'fa-solid fa-heart' : 'fa-regular fa-heart'} text-sm"></i>
                        </button>
                    </div>

                    <div class="flex-1 flex flex-col justify-between">
                        <div>
                            <div class="flex items-start justify-between gap-3 mb-1.5">
                                <div>
                                    <span class="inline-block bg-primary-subtle text-primary font-bold text-[10px] px-2 py-0.5 rounded-md mb-1">${dish.category}</span>
                                    <h3 class="font-extrabold text-base sm:text-lg text-text-main group-hover:text-primary transition-colors leading-snug">
                                        <a href="${link}">${dish.name}</a>
                                    </h3>
                                </div>
                                <div class="flex items-center gap-1 text-xs font-bold text-rose-600 bg-rose-50 px-2 py-1 rounded-lg shrink-0" title="${dish.likes} lượt yêu thích">
                                    <i class="fa-solid fa-heart text-rose-500 text-[10px]"></i>
                                    <span class="card-likes-count" data-food-id="${dish.id}">${dish.likes >= 1000 ? (dish.likes / 1000).toFixed(1).replace('.0', '') + 'k' : dish.likes}</span>
                                </div>
                            </div>
                            <p class="text-xs sm:text-sm text-text-muted line-clamp-2 mb-3 leading-relaxed">
                                ${dish.description}
                            </p>
                            <div class="flex flex-wrap items-center gap-1.5 mb-3">
                                ${dish.tags.slice(0, 3).map(tag => `
                                    <span class="bg-[#F8F5EC] border border-[#EBE3D3] text-text-muted text-[10px] font-semibold px-2 py-0.5 rounded-md">${tag}</span>
                                `).join('')}
                            </div>
                        </div>

                        <div class="pt-3 border-t border-[#F0EBE0] flex items-center justify-between">
                            <div class="flex items-center gap-1.5 text-xs text-text-muted font-medium">
                                <i class="fa-solid fa-kitchen-set text-primary text-[11px]"></i>
                                <span>${dish.difficulty}</span>
                            </div>
                            <a 
                                href="${link}" 
                                class="inline-flex items-center gap-1.5 bg-primary/10 hover:bg-primary text-primary hover:text-white font-bold text-xs px-4 py-2 rounded-xl transition-all duration-200 cursor-pointer"
                            >
                                <span>Xem công thức</span>
                                <i class="fa-solid fa-arrow-right text-[10px]"></i>
                            </a>
                        </div>
                    </div>
                `;
                return article;
            }

            // Grid View Card (3 cards per row on desktop, uniform height)
            article.className = "bg-white rounded-[20px] border border-beige-border/80 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 flex flex-col h-full overflow-hidden group cursor-pointer";
            article.id = `dish-card-${dish.id}`;
            article.setAttribute('data-dish-id', dish.id);
            article.setAttribute('data-link', link);
            article.innerHTML = `
                <div class="relative aspect-[16/10] overflow-hidden bg-cream-soft shrink-0">
                    <img 
                        src="${dish.image}" 
                        alt="${dish.name}" 
                        class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out" 
                        loading="lazy" 
                        decoding="async"
                        onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500'"
                    />
                    <div class="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                    <div class="absolute bottom-2.5 left-2.5 bg-black/60 backdrop-blur-md text-white px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1.5 shadow-sm z-10">
                        <i class="fa-regular fa-clock text-accent-light text-[10px]"></i>
                        <span>${dish.time}</span>
                    </div>

                    <button 
                        type="button" 
                        class="btn-favorite-dish absolute top-2.5 right-2.5 w-8.5 h-8.5 rounded-full ${isFav ? 'bg-rose-500 text-white' : 'bg-white/90 text-gray-500 hover:text-rose-500'} backdrop-blur-sm flex items-center justify-center shadow-sm hover:scale-110 transition-all cursor-pointer z-20" 
                        data-id="${dish.id}" 
                        aria-label="Thêm vào yêu thích"
                    >
                        <i class="${isFav ? 'fa-solid fa-heart' : 'fa-regular fa-heart'} text-sm"></i>
                    </button>
                </div>

                <div class="p-4 sm:p-4.5 flex flex-col flex-1">
                    <div class="flex items-start justify-between gap-2 mb-1.5">
                        <h3 class="font-extrabold text-sm sm:text-base text-text-main line-clamp-2 leading-snug group-hover:text-primary transition-colors flex-1">
                            <a href="${link}">${dish.name}</a>
                        </h3>
                        <div class="flex items-center gap-1 text-[11px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded-md shrink-0 mt-0.5" title="${dish.likes} lượt yêu thích">
                            <i class="fa-solid fa-heart text-rose-500 text-[10px]"></i>
                            <span class="card-likes-count" data-food-id="${dish.id}">${dish.likes >= 1000 ? (dish.likes / 1000).toFixed(1).replace('.0', '') + 'k' : dish.likes}</span>
                        </div>
                    </div>

                    <p class="text-xs text-text-muted line-clamp-2 mb-3 leading-relaxed font-normal">
                        ${dish.description}
                    </p>

                    <div class="flex flex-wrap items-center gap-1.5 mb-3.5 mt-auto">
                        <span class="bg-primary-subtle border border-primary-light/30 text-primary text-[10px] font-bold px-2 py-0.5 rounded-md">${dish.category}</span>
                        <span class="bg-[#F8F5EC] border border-[#EBE3D3] text-text-muted text-[10px] font-semibold px-2 py-0.5 rounded-md">${dish.difficulty}</span>
                    </div>

                    <div class="pt-3 border-t border-[#F0EBE0] mt-auto">
                        <a 
                            href="${link}" 
                            class="w-full py-2 bg-primary/8 hover:bg-primary text-primary hover:text-white font-bold text-xs rounded-xl transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs group-hover:shadow-sm"
                        >
                            <span>Xem công thức</span>
                            <i class="fa-solid fa-arrow-right text-[10px] group-hover:translate-x-1 transition-transform"></i>
                        </a>
                    </div>
                </div>
            `;
            return article;
        };

        // Render Shimmer Skeleton Cards HTML
        const createSkeletonCardsHTML = (count = 3) => {
            let html = '';
            for (let i = 0; i < count; i++) {
                html += `
                    <div class="bg-white rounded-[20px] border border-beige-border/80 p-4 shadow-sm animate-pulse space-y-3">
                        <div class="w-full aspect-[16/10] bg-[#ECE5D8] rounded-xl"></div>
                        <div class="space-y-1.5">
                            <div class="w-3/4 h-4 bg-[#ECE5D8] rounded-md"></div>
                            <div class="w-1/2 h-3 bg-[#ECE5D8] rounded-md"></div>
                        </div>
                        <div class="w-full h-3 bg-[#ECE5D8] rounded-md"></div>
                        <div class="flex gap-2 pt-2 border-t border-[#F0EBE0]">
                            <div class="w-16 h-5 bg-[#ECE5D8] rounded-md"></div>
                            <div class="w-16 h-5 bg-[#ECE5D8] rounded-md"></div>
                        </div>
                    </div>
                `;
            }
            return html;
        };

        // Update Toolbar & Mobile Badges
        const updateToolbarCounts = () => {
            const total = currentFilteredDishes.length;
            if (recipeTotalCountEl) {
                recipeTotalCountEl.textContent = `${total} món ăn phù hợp`;
            }
            if (mobileResultCountEl) {
                mobileResultCountEl.textContent = `${total} món ăn`;
            }

            const hasActiveFilters = currentSelectedCategories.length > 0 || 
                                     Boolean(currentQuickCategory) || 
                                     (currentCookTime && currentCookTime !== 'all') || 
                                     currentSelectedIngredients.length > 0 || 
                                     currentSearchQuery.trim() !== '';

            if (activeFilterIndicator) {
                activeFilterIndicator.classList.toggle('hidden', !hasActiveFilters);
            }

            let filterCount = 0;
            filterCount += currentSelectedCategories.length;
            if (currentQuickCategory) filterCount++;
            if (currentCookTime && currentCookTime !== 'all') filterCount++;
            filterCount += currentSelectedIngredients.length;
            if (currentSearchQuery.trim() !== '') filterCount++;

            if (mobileFilterBadge) {
                mobileFilterBadge.textContent = filterCount;
                mobileFilterBadge.classList.toggle('hidden', filterCount === 0);
            }
        };

        // Update Loading State (Shimmer / End of Feed indicator)
        const updateLoadingStateUI = () => {
            if (!loadingState) return;

            const total = currentFilteredDishes.length;
            if (total === 0) {
                loadingState.innerHTML = '';
                return;
            }

            if (!hasMore || currentIndex >= total) {
                loadingState.innerHTML = `
                    <div class="text-center py-6 text-text-muted text-xs font-medium w-full">
                        <div class="inline-flex items-center gap-2 bg-white/90 backdrop-blur-sm border border-beige-border px-5 py-2.5 rounded-full shadow-sm text-text-muted">
                            <span class="text-accent">🎉</span>
                            <span>Bạn đã xem hết các món ăn</span>
                        </div>
                    </div>
                `;
            } else {
                loadingState.innerHTML = `
                    <div class="text-center py-4 text-text-muted text-xs font-medium">
                        <span class="inline-flex items-center gap-2 text-text-muted opacity-80">
                            <i class="fa-solid fa-angles-down animate-bounce text-xs text-primary"></i>
                            <span>Cuộn xuống để khám phá thêm món ngon</span>
                        </span>
                    </div>
                `;
            }
        };

        // ====================================================================
        // INFINITE SCROLL & LAZY RENDERING ENGINE
        // Strictly appends to #recipe-grid without touching sidebar
        // ====================================================================
        const loadMoreRecipes = () => {
            if (isLoading || !hasMore) return;
            const total = currentFilteredDishes.length;
            if (currentIndex >= total) {
                hasMore = false;
                updateLoadingStateUI();
                return;
            }

            isLoading = true;

            // Show skeleton cards in #loading-state
            if (loadingState) {
                loadingState.innerHTML = `
                    <div class="w-full space-y-4">
                        <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                            ${createSkeletonCardsHTML(3)}
                        </div>
                        <div class="flex items-center justify-center gap-2 text-xs font-bold text-primary py-2">
                            <i class="fa-solid fa-spinner animate-spin text-sm text-accent"></i>
                            <span>Đang tải thêm món ngon...</span>
                        </div>
                    </div>
                `;
            }

            // Simulate realistic smooth lazy load delay
            setTimeout(() => {
                const nextBatch = currentFilteredDishes.slice(currentIndex, currentIndex + BATCH_SIZE);

                if (recipeGrid && nextBatch.length > 0) {
                    const fragment = document.createDocumentFragment();
                    nextBatch.forEach(dish => {
                        fragment.appendChild(createRecipeCardElement(dish));
                    });
                    recipeGrid.appendChild(fragment);
                }

                currentIndex += nextBatch.length;
                if (currentIndex >= total) {
                    hasMore = false;
                    if (infiniteScrollObserver) infiniteScrollObserver.disconnect();
                }

                isLoading = false;
                updateToolbarCounts();
                updateLoadingStateUI();
            }, 450);
        };

        // Setup Intersection Observer on #loading-sentinel
        const setupInfiniteScroll = () => {
            if (infiniteScrollObserver) {
                infiniteScrollObserver.disconnect();
            }

            if (!loadingSentinel || !hasMore) return;

            infiniteScrollObserver = new IntersectionObserver((entries) => {
                const entry = entries[0];
                if (entry && entry.isIntersecting) {
                    if (!isLoading && hasMore) {
                        loadMoreRecipes();
                    }
                }
            }, {
                root: null,
                rootMargin: '400px',
                threshold: 0
            });

            infiniteScrollObserver.observe(loadingSentinel);
        };

        // Render First Batch on Filter / Search Change
        const renderFirstBatch = () => {
            if (!recipeGrid) return;

            currentIndex = 0;
            hasMore = true;
            isLoading = false;
            updateToolbarCounts();

            // Clear ONLY recipe-grid
            recipeGrid.innerHTML = '';

            // Handle Empty State
            if (currentFilteredDishes.length === 0) {
                hasMore = false;
                recipeGrid.className = "w-full col-span-full";
                recipeGrid.innerHTML = `
                    <div class="bg-white rounded-[24px] border border-beige-border/80 p-8 sm:p-12 text-center shadow-sm max-w-lg mx-auto space-y-4">
                        <div class="w-20 h-20 rounded-full bg-cream-soft flex items-center justify-center text-3xl mx-auto text-primary border border-[#E9DFC9]">
                            <i class="fa-solid fa-bowl-rice"></i>
                        </div>
                        <div class="space-y-1">
                            <h3 class="text-base sm:text-lg font-extrabold text-text-main">Chưa tìm thấy món phù hợp</h3>
                            <p class="text-xs sm:text-sm text-text-muted font-medium">Thử thay đổi từ khóa hoặc bộ lọc nhé!</p>
                        </div>
                        <button 
                            type="button" 
                            id="btn-empty-reset" 
                            class="inline-flex items-center gap-2 bg-primary hover:bg-[#1B4633] text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-full shadow-md transition-all cursor-pointer"
                        >
                            <i class="fa-solid fa-rotate-right text-xs"></i>
                            <span>Xóa bộ lọc</span>
                        </button>
                    </div>
                `;

                const btnEmptyReset = document.getElementById('btn-empty-reset');
                if (btnEmptyReset) {
                    btnEmptyReset.addEventListener('click', resetAllFilters);
                }

                if (loadingState) loadingState.innerHTML = '';
                return;
            }

            // Restore layout class
            if (viewMode === 'grid') {
                recipeGrid.className = "recipe-grid grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6";
            } else {
                recipeGrid.className = "recipe-grid flex flex-col gap-4";
            }

            // Render first batch of 12 cards using DocumentFragment
            const firstBatch = currentFilteredDishes.slice(0, BATCH_SIZE);
            const fragment = document.createDocumentFragment();
            firstBatch.forEach(dish => {
                fragment.appendChild(createRecipeCardElement(dish));
            });
            recipeGrid.appendChild(fragment);

            currentIndex = firstBatch.length;
            if (currentIndex >= currentFilteredDishes.length) {
                hasMore = false;
            }

            updateLoadingStateUI();
            setupInfiniteScroll();
        };

        // ====================================================================
        // FILTER & SORT LOGIC
        // ====================================================================
        const runClientFilter = () => {
            let result = [...masterDishes];

            if (currentSearchQuery.trim() !== '') {
                const q = currentSearchQuery.toLowerCase().trim();
                result = result.filter(d => 
                    d.name.toLowerCase().includes(q) ||
                    d.description.toLowerCase().includes(q) ||
                    d.ingredients.some(ing => ing.toLowerCase().includes(q)) ||
                    d.tags.some(t => t.toLowerCase().includes(q))
                );
            }

            if (currentQuickCategory === 'nhanh') {
                result = result.filter(d => d.cooking_time_minutes > 0 && d.cooking_time_minutes <= 15);
            } else if (currentQuickCategory && currentQuickCategory !== 'all') {
                result = result.filter(d => d.sub_category === currentQuickCategory);
            }

            if (currentSelectedCategories.length > 0) {
                const targetCats = currentSelectedCategories.map(c => c.toLowerCase());
                result = result.filter(d => 
                    targetCats.includes(d.category.toLowerCase()) || 
                    (d.category_slug && targetCats.includes(d.category_slug.toLowerCase()))
                );
            }

            if (currentCookTime === 'under_15') {
                result = result.filter(d => d.cooking_time_minutes <= 15);
            } else if (currentCookTime === '15_to_30') {
                result = result.filter(d => d.cooking_time_minutes > 15 && d.cooking_time_minutes <= 30);
            } else if (currentCookTime === 'above_30') {
                result = result.filter(d => d.cooking_time_minutes > 30);
            }

            if (currentSelectedIngredients.length > 0) {
                result = result.filter(d => 
                    currentSelectedIngredients.some(selectedIng => 
                        d.ingredients.some(dishIng => dishIng.toLowerCase().includes(selectedIng.toLowerCase()))
                    )
                );
            }

            if (currentSort === 'newest') {
                result.sort((a, b) => b.id - a.id);
            } else if (currentSort === 'popular') {
                result.sort((a, b) => (parseFloat(b.rating_count) || 0) - (parseFloat(a.rating_count) || 0));
            } else if (currentSort === 'likes') {
                result.sort((a, b) => b.likes - a.likes);
            } else if (currentSort === 'rating') {
                result.sort((a, b) => b.rating - a.rating);
            } else if (currentSort === 'time_asc') {
                result.sort((a, b) => a.cooking_time_minutes - b.cooking_time_minutes);
            } else if (currentSort === 'time_desc') {
                result.sort((a, b) => b.cooking_time_minutes - a.cooking_time_minutes);
            } else if (currentSort === 'name_asc') {
                result.sort((a, b) => a.name.localeCompare(b.name, 'vi'));
            }

            return result;
        };

        const executeFilterAndSort = async () => {
            const requestId = ++latestRequestId;
            let result = [];
            try {
                const queryParams = new URLSearchParams();
                queryParams.set('limit', '50');

                if (currentSearchQuery && currentSearchQuery.trim()) {
                    queryParams.set('search', currentSearchQuery.trim());
                }

                if (currentSelectedCategories.length > 0) {
                    queryParams.set('category', currentSelectedCategories.join(','));
                }

                if (currentQuickCategory && currentQuickCategory !== 'all') {
                    queryParams.set('sub_category', currentQuickCategory);
                }

                if (currentCookTime && currentCookTime !== 'all') {
                    queryParams.set('cook_time', currentCookTime);
                }

                if (currentSelectedIngredients && currentSelectedIngredients.length > 0) {
                    queryParams.set('ingredients', currentSelectedIngredients.join(','));
                }

                if (currentSort && currentSort !== 'newest') {
                    queryParams.set('sort', currentSort);
                }

                const endpoint = `/foods?${queryParams.toString()}`;
                const apiRes = await fetchAPI(endpoint);
                if (apiRes && apiRes.success && Array.isArray(apiRes.data)) {
                    result = apiRes.data.map(item => ({
                        id: item.id || item.id_food || item.id_monan,
                        name: item.name || item.ten_mon || 'Món ngon',
                        image: item.image || item.hinh_anh || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700',
                        time: item.time || (item.thoi_gian ? `${item.thoi_gian} phút` : '25 phút'),
                        cooking_time_minutes: parseInt(item.cooking_time_minutes || item.thoi_gian || 25, 10),
                        rating: item.rating || 4.8,
                        rating_count: item.rating_count || '1.5k',
                        likes: typeof item.likes !== 'undefined' ? item.likes : 0,
                        is_favorite: Boolean(item.is_favorite ?? item.isFavorite),
                        category: item.category || item.loai_mon || 'Món mặn',
                        category_slug: item.category_slug || '',
                        sub_category: item.sub_category || 'viet',
                        difficulty: item.difficulty || 'Dễ làm',
                        description: item.description || item.mo_ta || 'Món ăn thơm ngon đậm đà cho bữa cơm gia đình.',
                        ingredients: item.ingredients || ['Rau củ', 'Gia vị'],
                        tags: item.tags || ['Món ngon', 'Món Việt'],
                        author: item.author || { name: 'Bếp Nhà', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100' }
                    }));
                } else {
                    result = runClientFilter();
                }
            } catch (e) {
                result = runClientFilter();
            }

            if (requestId !== latestRequestId) return;

            currentFilteredDishes = result;
            renderFirstBatch();
        };

        const resetAllFilters = () => {
            currentSelectedCategories = [];
            currentQuickCategory = '';
            currentCookTime = 'all';
            currentSelectedIngredients = [];
            currentSearchQuery = '';
            currentSort = 'newest';

            if (heroSearchInput) heroSearchInput.value = '';
            if (btnClearSearch) btnClearSearch.classList.add('hidden');

            document.querySelectorAll('.quick-cat-btn').forEach(btn => {
                btn.className = "quick-cat-btn px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-[#E5DEC9] bg-white/80 text-text-muted hover:text-primary hover:bg-primary-subtle shadow-2xs";
            });

            document.querySelectorAll('.btn-filter-cat').forEach(btn => {
                btn.className = "btn-filter-cat px-2 py-1.5 rounded-lg text-[11px] font-semibold text-text-muted text-left transition-all border border-gray-100 hover:bg-cream-soft hover:text-primary cursor-pointer flex items-center justify-between";
                const checkIcon = btn.querySelector('.fa-check');
                if (checkIcon) checkIcon.remove();
            });

            const allRadio = document.querySelector('input[name="cook_time"][value="all"]');
            if (allRadio) allRadio.checked = true;

            document.querySelectorAll('.ingredient-checkbox').forEach(cb => {
                cb.checked = false;
            });

            if (currentSortLabel) currentSortLabel.textContent = 'Mới nhất';

            executeFilterAndSort();
            showToast('Đã đặt lại toàn bộ bộ lọc', 'info');
        };

        // ====================================================================
        // EVENT HANDLERS & LISTENERS
        // ====================================================================

        // 1. Search Input & Debounce
        if (heroSearchInput) {
            heroSearchInput.addEventListener('input', (e) => {
                const val = e.target.value;
                if (btnClearSearch) {
                    btnClearSearch.classList.toggle('hidden', val.length === 0);
                }

                clearTimeout(searchDebounceTimer);
                searchDebounceTimer = setTimeout(() => {
                    currentSearchQuery = val;
                    executeFilterAndSort();
                }, 300);
            });
        }

        if (btnClearSearch) {
            btnClearSearch.addEventListener('click', () => {
                if (heroSearchInput) {
                    heroSearchInput.value = '';
                    btnClearSearch.classList.add('hidden');
                    currentSearchQuery = '';
                    executeFilterAndSort();
                }
            });
        }

        if (heroSearchForm) {
            heroSearchForm.addEventListener('submit', (e) => {
                e.preventDefault();
                currentSearchQuery = heroSearchInput?.value || '';
                executeFilterAndSort();
            });
        }

        const quickCatBtns = document.querySelectorAll('.quick-cat-btn');
        quickCatBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const cat = btn.getAttribute('data-cat');
                if (currentQuickCategory === cat) {
                    currentQuickCategory = '';
                    btn.className = "quick-cat-btn px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-[#E5DEC9] bg-white/80 text-text-muted hover:text-primary hover:bg-primary-subtle shadow-2xs";
                } else {
                    currentQuickCategory = cat;
                    quickCatBtns.forEach(b => {
                        b.className = "quick-cat-btn px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-[#E5DEC9] bg-white/80 text-text-muted hover:text-primary hover:bg-primary-subtle shadow-2xs";
                    });
                    btn.className = "quick-cat-btn active-pill px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border shadow-2xs";
                }

                executeFilterAndSort();
            });
        });

        const catButtons = document.querySelectorAll('.btn-filter-cat');
        catButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const cat = btn.getAttribute('data-cat');
                const idx = currentSelectedCategories.indexOf(cat);
                if (idx > -1) {
                    currentSelectedCategories.splice(idx, 1);
                    btn.className = "btn-filter-cat px-2 py-1.5 rounded-lg text-[11px] font-semibold text-text-muted text-left transition-all border border-gray-100 hover:bg-cream-soft hover:text-primary cursor-pointer flex items-center justify-between";
                    const ic = btn.querySelector('.fa-check');
                    if (ic) ic.remove();
                } else {
                    currentSelectedCategories.push(cat);
                    btn.className = "btn-filter-cat active-cat px-2 py-1.5 rounded-lg text-[11px] font-bold text-left transition-all border cursor-pointer flex items-center justify-between bg-primary-subtle text-primary border-primary/40";
                    if (!btn.querySelector('.fa-check')) {
                        const checkIcon = document.createElement('i');
                        checkIcon.className = "fa-solid fa-check text-[9px] text-primary shrink-0 ml-1";
                        btn.appendChild(checkIcon);
                    }
                }

                executeFilterAndSort();
            });
        });

        const timeRadios = document.querySelectorAll('input[name="cook_time"]');
        timeRadios.forEach(r => {
            r.addEventListener('change', () => {
                currentCookTime = r.value;
                executeFilterAndSort();
            });
        });

        const ingredientCheckboxes = document.querySelectorAll('.ingredient-checkbox');
        ingredientCheckboxes.forEach(cb => {
            cb.addEventListener('change', () => {
                const checked = Array.from(document.querySelectorAll('.ingredient-checkbox:checked')).map(item => item.value);
                currentSelectedIngredients = checked;
                executeFilterAndSort();
            });
        });

        // 6. Reset Filters Buttons
        if (btnResetAllFilters) btnResetAllFilters.addEventListener('click', resetAllFilters);
        if (btnResetFiltersSidebar) btnResetFiltersSidebar.addEventListener('click', resetAllFilters);

        // 7. Sort Dropdown Toggle & Options
        if (btnSortToggle && sortDropdownMenu) {
            btnSortToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                sortDropdownMenu.classList.toggle('hidden');
                btnSortToggle.setAttribute('aria-expanded', !sortDropdownMenu.classList.contains('hidden'));
            });

            document.addEventListener('click', (e) => {
                if (!sortDropdownMenu.contains(e.target) && e.target !== btnSortToggle) {
                    sortDropdownMenu.classList.add('hidden');
                    btnSortToggle.setAttribute('aria-expanded', 'false');
                }
            });

            document.querySelectorAll('.btn-sort-option').forEach(optBtn => {
                optBtn.addEventListener('click', () => {
                    const sortVal = optBtn.getAttribute('data-sort');
                    const sortLabelText = optBtn.getAttribute('data-label');
                    currentSort = sortVal;
                    if (currentSortLabel) currentSortLabel.textContent = sortLabelText;
                    sortDropdownMenu.classList.add('hidden');
                    btnSortToggle.setAttribute('aria-expanded', 'false');
                    executeFilterAndSort();
                });
            });
        }

        // 8. View Mode Switcher (Grid / List)
        if (btnViewGrid && btnViewList) {
            btnViewGrid.addEventListener('click', () => {
                if (viewMode === 'grid') return;
                viewMode = 'grid';
                btnViewGrid.className = "w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold bg-primary text-white shadow-2xs transition-all cursor-pointer";
                btnViewList.className = "w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-text-muted hover:text-primary transition-all cursor-pointer";
                renderFirstBatch();
            });

            btnViewList.addEventListener('click', () => {
                if (viewMode === 'list') return;
                viewMode = 'list';
                btnViewList.className = "w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold bg-primary text-white shadow-2xs transition-all cursor-pointer";
                btnViewGrid.className = "w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-text-muted hover:text-primary transition-all cursor-pointer";
                renderFirstBatch();
            });
        }

        // 9. Card Event Delegation: Favorite Heart Click on #recipe-grid
        if (recipeGrid) {
            recipeGrid.addEventListener('click', async (e) => {
                const favBtn = e.target.closest('.btn-favorite-dish');
                if (favBtn) {
                    e.preventDefault();
                    e.stopPropagation();
                    const dishId = parseInt(favBtn.getAttribute('data-id'), 10);
                    const dish = masterDishes.find(d => d.id === dishId);
                    if (!dish) return;

                    if (typeof window !== 'undefined' && window.toggleFavoriteDish) {
                        const isFav = await window.toggleFavoriteDish(dish);
                        dish.is_favorite = isFav;
                    } else if (typeof window !== 'undefined' && window.toggleFoodFavorite) {
                        await window.toggleFoodFavorite(e, dishId);
                    } else {
                        dish.is_favorite = !dish.is_favorite;
                        const heartIcon = favBtn.querySelector('i');
                        if (dish.is_favorite) {
                            favBtn.className = "btn-favorite-dish absolute top-2.5 right-2.5 w-8.5 h-8.5 rounded-full bg-rose-500 text-white backdrop-blur-sm flex items-center justify-center shadow-sm scale-125 transition-all cursor-pointer z-20";
                            setTimeout(() => favBtn.classList.remove('scale-125'), 150);
                            if (heartIcon) heartIcon.className = "fa-solid fa-heart text-sm";
                            showToast(`Đã thêm "${dish.name}" vào Yêu thích! ❤️`, 'success');
                        } else {
                            favBtn.className = "btn-favorite-dish absolute top-2.5 right-2.5 w-8.5 h-8.5 rounded-full bg-white/90 text-gray-500 hover:text-rose-500 backdrop-blur-sm flex items-center justify-center shadow-sm transition-all cursor-pointer z-20";
                            if (heartIcon) heartIcon.className = "fa-regular fa-heart text-sm";
                            showToast(`Đã bỏ lưu "${dish.name}"`, 'info');
                        }
                    }
                    return;
                }

                // Click vào bất kỳ đâu trên card món ăn -> Mở trang chi tiết món
                const card = e.target.closest('article[id^="dish-card-"]');
                if (card) {
                    const link = card.getAttribute('data-link') || `#/mon-an/${card.getAttribute('data-dish-id') || card.id.replace('dish-card-', '')}`;
                    if (link) {
                        window.location.hash = link;
                    }
                }
            });
        }

        // 10. Mobile Filter Modal Toggle
        if (btnOpenMobileFilter && mobileFilterModal) {
            btnOpenMobileFilter.addEventListener('click', () => {
                mobileFilterModal.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            });
        }

        const closeMobileFilter = () => {
            if (mobileFilterModal) {
                mobileFilterModal.classList.add('hidden');
                document.body.style.overflow = '';
            }
        };

        if (btnCloseMobileFilter) btnCloseMobileFilter.addEventListener('click', closeMobileFilter);
        if (mobileFilterBackdrop) mobileFilterBackdrop.addEventListener('click', closeMobileFilter);

        if (btnMobileApply) {
            btnMobileApply.addEventListener('click', () => {
                closeMobileFilter();
            });
        }

        if (btnMobileReset) {
            btnMobileReset.addEventListener('click', () => {
                resetAllFilters();
                closeMobileFilter();
            });
        }

        // ====================================================================
        // INITIAL RENDER
        // ====================================================================
        const urlParams = params instanceof URLSearchParams 
            ? params 
            : new URLSearchParams(window.location.hash.includes('?') ? window.location.hash.split('?')[1] : '');

        const urlSort = urlParams.get('sort');
        const urlCat = urlParams.get('category');
        const urlTime = urlParams.get('cook_time') || urlParams.get('time');
        const urlSubCat = urlParams.get('sub_category');
        const urlSearch = urlParams.get('search');

        if (urlSort) {
            currentSort = urlSort;
            const sortMatch = sortOptions.find(o => o.value === urlSort);
            if (sortMatch && currentSortLabel) {
                currentSortLabel.textContent = sortMatch.label;
            }
        }

        if (urlCat) {
            const parsedCats = urlCat.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
            catButtons.forEach(b => {
                const bCat = b.getAttribute('data-cat');
                const bCatSlug = bCat ? bCat.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, '-') : '';
                const isMatch = bCat && (parsedCats.includes(bCat.toLowerCase()) || parsedCats.includes(bCatSlug));
                if (isMatch) {
                    if (!currentSelectedCategories.includes(bCat)) {
                        currentSelectedCategories.push(bCat);
                    }
                    b.className = "btn-filter-cat active-cat px-2 py-1.5 rounded-lg text-[11px] font-bold text-left transition-all border cursor-pointer flex items-center justify-between bg-primary-subtle text-primary border-primary/40";
                    if (!b.querySelector('.fa-check')) {
                        const checkIcon = document.createElement('i');
                        checkIcon.className = "fa-solid fa-check text-[9px] text-primary shrink-0 ml-1";
                        b.appendChild(checkIcon);
                    }
                }
            });
        }

        if (urlTime) {
            currentCookTime = urlTime;
            const targetRadio = document.querySelector(`input[name="cook_time"][value="${urlTime}"]`);
            if (targetRadio) {
                targetRadio.checked = true;
            }
        }

        if (urlSubCat) {
            currentQuickCategory = urlSubCat;
            quickCatBtns.forEach(b => {
                const isMatch = b.getAttribute('data-cat') === urlSubCat;
                b.className = isMatch
                    ? "quick-cat-btn active-pill px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border shadow-2xs"
                    : "quick-cat-btn px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-[#E5DEC9] bg-white/80 text-text-muted hover:text-primary hover:bg-primary-subtle shadow-2xs";
            });
        }

        if (urlSearch) {
            currentSearchQuery = urlSearch;
            if (heroSearchInput) heroSearchInput.value = urlSearch;
            if (btnClearSearch) btnClearSearch.classList.remove('hidden');
        }

        executeFilterAndSort();
        if (window.updateNavbarFavBadge) window.updateNavbarFavBadge();
    }
};

export default FoodList;
